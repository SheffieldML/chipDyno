pods
===

# Python open data science software. 

This repository contains utilities and tools for open data science including tools for accessing data sets in python. 

This is very much an *alpha* release.

## Datasets

There is a set of notebooks describing the data sets that can be accessed available in the notebooks subdirectory. 

## Google Docs Interface

If the `gdata` package is installed (`pip install gdata`) the library can be used as an interface between google spreadsheets and pandas.
