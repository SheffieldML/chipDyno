chipTuTextRead <-
function(file_dictionary, file_probeIDTu, file_data, file_vars){

dictionary <- read.table(file_dictionary, header = FALSE, sep = "\t", 
				quote = "", dec = ".", col.names=c("IDs_temp", "ORF", 
				"ORF_temp","geneCN_temp"), na.strings = "NA", 
				colClasses = NA, nrows = -1, skip = 0, check.names = TRUE, 
				fill = TRUE, strip.white = FALSE, blank.lines.skip = FALSE, 
				comment.char = "#", allowEscapes = FALSE, flush = FALSE)

ORF= matrix(dictionary$ORF,,1) 
IDs= matrix(dictionary$IDs_temp,,1)

probeIDTu <- read.table(file_probeIDTu, sep=" ", fill= TRUE, col.names=c("IDSn"))
IDSnew <- matrix(probeIDTu$IDSn,,1)
data = as.matrix(read.table(file_data))
vars=as.matrix(read.table(file_vars))
ORF_data_vars= list(ORF, data, vars)

return(ORF_data_vars)
}
