chipTextRead <-
function(data_file) {

dictionary <- read.table(data_file, header = TRUE, sep = "\t", quote = "", 
				dec = ".", , na.strings = "NA", colClasses = NA, nrows = -1, 
				skip = 0, check.names = TRUE, fill = TRUE, strip.white = FALSE, 
				blank.lines.skip = TRUE, comment.char = "#", 
				allowEscapes = FALSE, flush = FALSE)

dictionary[is.na(dictionary)] <- 0

geneName = as.matrix(dictionary[,1],,1)
data = dictionary [, 2: ncol(dictionary)] 

geneName_data = list(geneName, data)
return(geneName_data)
}
