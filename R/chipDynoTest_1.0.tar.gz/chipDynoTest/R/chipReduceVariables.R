chipReduceVariables <-
function(X){

nGenes=nrow(X)
preSigma1=X[1,]
preSigma1=matrix(preSigma1,1,)
preSigma2=preSigma1

for (i in 2: nGenes){
	preSigma2 = rbind(preSigma2,X[i,])
	matrix1=t(preSigma1)%*%preSigma1
	matrix2=t(preSigma2)%*%preSigma2
	decider=min(matrix1[which(matrix2 !=0)])
	if (decider==0)
		preSigma1=rbind(preSigma1,X[i,])
}

nEffectGenes=nrow(preSigma1)
R = row(preSigma1)[which(preSigma1 != 0)]
C = col(preSigma1)[which(preSigma1 != 0)]
V = preSigma1[which(preSigma1 != 0)]

val= list(R,C,V,nEffectGenes)
return (val)
}
