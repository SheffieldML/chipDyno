SCGoptimTU <-
function(x, options, data, precs, X, nEffectGenes, R, C) {

# 'params' assigned to x, rest others variables are same.
# f = chipDynoLikeStatNoise
# x = params
# options = options
# gradf = chipDynoLikeStatNoiseGrad
# varargin = data, X, nEffectGenes, R, C

# options = array(0, dim=c(1,18))
# options[1]=1;
# options[2]=0.0001
# options[3]=0.0001
# options[14]=10 # No of iteration
# options[17]=0.1
eps= 2.2204e-16

#  Set up the options.
if (length(options) < 18){
  stop('Options vector too short')
}

#%  Set up the options.
#if length(options) < 18
#  error('Options vector too short')
#end

if(options[14]!=0){
	niters = options[14];
} else {
	niters = 10;
}

#if(options(14))
#  niters = options(14);
#else
#  niters = 100;
#end

display = options[1];
gradcheck = options[9];

#display = options(1);
#gradcheck = options(9);

##TODO
#% Set up strings for evaluating function and gradient
#f = fcnchk(f, length(varargin));
#gradf = fcnchk(gradf, length(varargin));
####

nparams = length(x)
#nparams = length(x);

#TODO  Check gradients
#if (gradcheck!=0){
#	feval('gradchek', x, f, gradf, varargin{:});
#}


#%  Check gradients
#if (gradcheck)
#  feval('gradchek', x, f, gradf, varargin{:});
#end


sigma0 = 1.0e-4;
fold = chipDynoLikeStatNoise(x,data,precs, X,nEffectGenes,R,C);	# Initial function value.
fnow = fold;
options[10] = options[10] + 1;		# Increment function evaluation counter.

#sigma0 = 1.0e-4;
#fold = feval(f, x, varargin{:});	% Initial function value.
#fnow = fold;
#options(10) = options(10) + 1;		% Increment function evaluation counter.

#TODO 
gradnew = chipDynoLikeStatNoiseGrad(x, data, precs, X, nEffectGenes, R, C);	# Initial gradient.
#gradnew=params

# gradnew = params ###temporary value update
gradold = gradnew;
options[11] = options[11] + 1;		# Increment gradient evaluation counter.

#gradnew = feval(gradf, x, varargin{:});	% Initial gradient.
#gradold = gradnew;
#options(11) = options(11) + 1;		% Increment gradient evaluation counter.

d = -gradnew;				# Initial search direction.
success = 1;				# Force calculation of directional derivs.
nsuccess = 0;				# nsuccess counts number of successes.
beta = 1.0;				# Initial scale parameter.
betamin = 1.0e-15; 			# Lower bound on scale.
betamax = 1.0e100;			# Upper bound on scale.
j = 1;					# j counts number of iterations.

#d = -gradnew;				% Initial search direction.
#success = 1;				% Force calculation of directional derivs.
#nsuccess = 0;				% nsuccess counts number of successes.
#beta = 1.0;				% Initial scale parameter.
#betamin = 1.0e-15; 			% Lower bound on scale.
#betamax = 1.0e100;			% Upper bound on scale.
#j = 1;					% j counts number of iterations.

## for test save.image("test2.RData")
flog = array(0, dim=c(niters,1))
pointlog = array(0, dim=c(niters,length(params)))
scalelog = array(0, dim=c(niters,1))
###

flog[j,] = fold
pointlog[j,] = x;
######### this segment doesn't work
#if (nargout >= 3){
#	flog[j,] = fold;
#	if (nargout == 4){
#		pointlog[j,] = x;
#	}
#}
##########


#if nargout >= 3
#  flog(j, :) = fold;
#  if nargout == 4
#    pointlog(j, :) = x;
#  end
#end


# Main optimization loop.

while (j <= niters){

#% Main optimization loop.
#while (j <= niters)

	if (success==1){
	mu = d %*% t(gradnew)
		if (mu >= 0){
			d= -gradnew
			mu = d %*% t(gradnew)
		}
	kappa = d%*%t(d)
	# eps= 2.2204e-16
		if (kappa < eps){
			options[8] = fnow;
			return(x) ##?? gradnew?
		}
#  % Calculate first and second directional derivatives.
#  if (success == 1)
#    mu = d*gradnew';
#    if (mu >= 0)
#      d = - gradnew;
#      mu = d*gradnew';
#    end
#    kappa = d*d';
#    if kappa < eps
#      options(8) = fnow;
#      return
#    end

	sigma = sigma0/sqrt(kappa)
	xplus = x + sigma%*%d
	#gplus = chipDynoLikeStatNoiseGrad(gradf, xplus, varargin{:});
	#TODO
	gplus = chipDynoLikeStatNoiseGrad(xplus, data, precs, X, nEffectGenes, R, C)
	#gplus = params^2
	
	options[11]= options[11] + 1
	theta = (d%*%(t(gplus) - t(gradnew)))/sigma
	}
#    sigma = sigma0/sqrt(kappa);
#    xplus = x + sigma*d;
#    gplus = feval(gradf, xplus, varargin{:});
#    options(11) = options(11) + 1; 
#    theta = (d*(gplus' - gradnew'))/sigma;
#  end

#  % Increase effective curvature and evaluate step size alpha.
	delta = theta + beta*kappa
	if (delta <= 0){ 
		delta = beta*kappa;
		beta = beta - theta/kappa;
	}
	alpha = - mu/delta;

#  % Increase effective curvature and evaluate step size alpha.
#  delta = theta + beta*kappa;
#  if (delta <= 0) 
#    delta = beta*kappa;
#    beta = beta - theta/kappa;
#  end
#  alpha = - mu/delta;

  	#% Calculate the comparison ratio.
	xnew = x + alpha %*% d;
	#fnew = feval(f, xnew, varargin{:});
	fnew = chipDynoLikeStatNoise(xnew, data, precs, X, nEffectGenes, R, C)
	options[10] = options[10] + 1;
	Delta = 2*(fnew - fold)/(alpha*mu);


#  % Calculate the comparison ratio.
#  xnew = x + alpha*d;
#  fnew = feval(f, xnew, varargin{:});
#  options(10) = options(10) + 1;
#  Delta = 2*(fnew - fold)/(alpha*mu);

	if (Delta  >= 0){
		success = 1;
		nsuccess = nsuccess + 1;
		x = xnew;
		fnow = fnew;
	} else {
		success = 0;
		fnow = fold;
	}

#  if (Delta  >= 0)
#    success = 1;
#    nsuccess = nsuccess + 1;
#    x = xnew;
#    fnow = fnew;
#  else
#    success = 0;
#    fnow = fold;
#  end
	## not done yet
	flog[j] = fnow
	pointlog[j,] = x
	scalelog[j] = beta
	####

#  if nargout >= 3
#    % Store relevant variables
#    flog(j) = fnow;		% Current function value
#    if nargout >= 4
#      pointlog(j,:) = x;	% Current position
#      if nargout >= 5
#	scalelog(j) = beta;	% Current scale parameter
#      end
#    end
#  end

	if (display > 0){
		#sprintf("Cycle %4d  Error %11.6f  Scale %e", j, fnow, beta);
		cat("Cycle :", j, "\tError= ",  fnow, "\tScale= ", beta, "\n");
	}
    
#  if display > 0
#    fprintf(1, 'Cycle %4d  Error %11.6f  Scale %e\n', j, fnow, beta);
#  end

	if (success == 1){
	#    % Test for termination

#  if (success == 1)
#    % Test for termination

		if (max(abs(alpha%*%d)) < options[2] & max(abs(fnew-fold)) < options[3]){
			options[8] = fnew;
			#cat("Test point 1");
			return(x);
			#cat("Test point 2");

#    if (max(abs(alpha*d)) < options(2) & max(abs(fnew-fold)) < options(3))
#      options(8) = fnew;
#      return;

		} else {
			fold = fnew;
			gradold = gradnew;
			## TODO
			gradnew = chipDynoLikeStatNoiseGrad(x, data, precs, X, nEffectGenes, R, C)
			#gradnew=params^3			
			options[11] = options[11] + 1

#    else
#      % Update variables for new position
#      fold = fnew;
#      gradold = gradnew;
#      gradnew = feval(gradf, x, varargin{:});
#      options(11) = options(11) + 1;

			#      % If the gradient is zero then we are done.
			if (gradnew %*% t(gradnew) == 0){
				options[8] = fnew;
				#cat("Test point 3");
				return(x);
				#cat("Test point 4");
			}
		}
	}


#      % If the gradient is zero then we are done.
#      if (gradnew*gradnew' == 0)
#	options(8) = fnew;
#	return;
#      end
#    end
#  end


	#  % Adjust beta according to comparison ratio.
	if (Delta < 0.25){
		beta = min(4.0*beta, betamax);
		}
	if (Delta > 0.75){
		beta = max(0.5*beta, betamin);
		}


#  % Adjust beta according to comparison ratio.
#  if (Delta < 0.25)
#    beta = min(4.0*beta, betamax);
#  end
#  if (Delta > 0.75)
#    beta = max(0.5*beta, betamin);
#  end

	#  % Update search direction using Polak-Ribiere formula, or re-start 
	#  % in direction of negative gradient after nparams steps.
		if (nsuccess == nparams){
			d = -gradnew;
			nsuccess = 0;
		} else {
			if (success == 1){
				gamma = (gradold - gradnew)%*%t(gradnew)/(mu);
				d = gamma %*% d - gradnew;
				}
			}	

	j = j + 1;
}


#  % Update search direction using Polak-Ribiere formula, or re-start 
#  % in direction of negative gradient after nparams steps.
#  if (nsuccess == nparams)
#    d = -gradnew;
#    nsuccess = 0;
#  else
#    if (success == 1)
#      gamma = (gradold - gradnew)*gradnew'/(mu);
#      d = gamma*d - gradnew;
#    end
#  end
#  j = j + 1;
#end

#% If we get here, then we haven't terminated in the given number of 
#% iterations.

options[8] = fold;
if (options[1] >= 0){
	print('Warning: Maximum number of iterations has been exceeded');
}


#% If we get here, then we haven't terminated in the given number of 
#% iterations.

#options(8) = fold;
#if (options(1) >= 0)
#  disp('Warning: Maximum number of iterations has been exceeded');
#end

## TODO
#cat("Test point 5");
return(x)
}
