chipDynoMaxDiff <-
function(TF,TFErrorDiff) {

nTargets=nrow(TF);
npts=ncol(TF);
preDiffs=array(0, dim <- c(npts,npts));
diffs=array(0, dim <- c(npts,npts,nTargets));
f= array(0, dim <- c(1,nTargets));

for (i in 1: nTargets) {
	for (j in 2:(npts-1)) {
		for (l in j : npts) {
			preDiffs[j,l]=TF[i,j]-TF[i,l];
		}
	}
	diffs[ , ,i] = preDiffs - t(preDiffs);
	f[i]=max(diffs[,,i]/TFErrorDiff[,,i]);  ## ?? ./
}

return(f)
}
