chipChipTextRead <-
function(geneName_annotation_file, connectivity_file){

geneName_annotation  <- read.table(geneName_annotation_file, header = TRUE, sep = "\t", quote = "", dec = ".", , na.strings = "NA", colClasses = NA, nrows = -1, skip = 1, check.names = TRUE, fill = TRUE, strip.white = FALSE, blank.lines.skip = TRUE, comment.char = "#", allowEscapes = FALSE, flush = FALSE)

geneName = as.matrix(geneName_annotation[,1],,1)
annotation = as.matrix(geneName_annotation [,2],,1)

data  <- read.table(connectivity_file, header = FALSE, sep = "\t", quote = "", dec = ".", , na.strings = "NA", colClasses = NA, nrows = -1, skip = 0, check.names = TRUE, fill = TRUE, strip.white = FALSE, blank.lines.skip = TRUE, comment.char = "#", allowEscapes = FALSE, flush = FALSE)

f= list (geneName, annotation, data)
return (f)
}
