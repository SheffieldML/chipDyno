chipDynoExpectationsFastNoise <-
function(data,X,Sigma,beta, precs, gamma,mu, transNames, annotations, transName, geneName){

## Only for test purpose
# annotations = annotation
# transNames=TransNames
# transName= "ACE2"
# transName=activeNames[i]
# geneName="YHR143W"
####

npts=ncol(data);
nTrans=ncol(X);
c = class(geneName)

v= mat.or.vec(length(annotations),1)

if (c == 'character'){
	for (i in 1: nrow(annotations)) { 
		v[i] <- geneName==annotations[i,1]
		}
	x=data.matrix(X[which(v==1),])
	data=t(data[which(v==1),])
	precs = precs[which(v==1),]

} else if (c=='integer'){
	x=data.matrix(X[geneName,])
	data=data[geneName,]
	precs=precs[geneName,] ### t() ???

} else {
	print('Error: Genes can be identified either by number or name')
}

source("chipDynoStatPostEstNoise.R")
expectations=chipDynoStatPostEstNoise(data,x,Sigma,beta,precs,gamma,mu);

expectations.b=expectations[[1]]
expectations.tfError=expectations[[2]]
expectations.tfErrorDiffs=expectations[[3]]

index=which(transName==transNames);
if (x[index,]== 0) {
 print('Error: The gene selected is not a target of the transcription factor')
}

tf=expectations.b[,index];
ind=which(transName == transNames[which(x!=0)]);
tfErrors=expectations.tfError[,ind];
tfErrorsDiffs=expectations.tfErrorDiffs[,,ind];

expectations = list(tf,tfErrors,tfErrorsDiffs);

return(expectations)
}
